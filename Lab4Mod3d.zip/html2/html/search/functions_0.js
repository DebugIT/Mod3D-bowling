var searchData=
[
  ['setballspeed',['setballSpeed',['../class_ball.html#a655a2ac68857807d79d7b32c3dc46b19',1,'Ball']]],
  ['start',['Start',['../class_ball.html#ac82387db69cc078a600870dba29a064c',1,'Ball.Start()'],['../class_ball_movement.html#a30553c43b5f0edb4ab0b3d1c4b269993',1,'BallMovement.Start()'],['../class_color_change.html#a7851038dd8fb7ee037e3572e5ea0820e',1,'ColorChange.Start()']]]
];
