var searchData=
[
  ['nextcolor',['nextColor',['../class_color_change.html#a24d6e49ea48325fb5fb722bb80264339',1,'ColorChange']]]
];
