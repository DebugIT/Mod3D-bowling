var searchData=
[
  ['deletepin',['DeletePin',['../class_delete_pin.html',1,'']]],
  ['deletepin_2ecs',['DeletePin.cs',['../_delete_pin_8cs.html',1,'']]]
];
