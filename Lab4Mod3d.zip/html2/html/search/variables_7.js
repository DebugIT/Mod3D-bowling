var searchData=
[
  ['target',['target',['../classlook_at_script.html#a3b70e47b1a08454438cd971a9e752a70',1,'lookAtScript']]],
  ['turnspeed',['turnSpeed',['../class_ball.html#a7adb29497e06c56dc9dd0d55ded63aa2',1,'Ball']]]
];
