var searchData=
[
  ['deletepin',['DeletePin',['../class_delete_pin.html',1,'']]]
];
