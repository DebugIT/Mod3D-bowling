var searchData=
[
  ['update',['Update',['../class_ball.html#a237aaf0107c7bf3d7812dc8a9a642593',1,'Ball.Update()'],['../class_ball_movement.html#adec04489bea52562cc6e1e0048c23bc7',1,'BallMovement.Update()'],['../class_color_change.html#adcff0a9a82823d3e0c08ac2aa6dad8c6',1,'ColorChange.Update()']]]
];
