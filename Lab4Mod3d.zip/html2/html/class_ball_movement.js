var class_ball_movement =
[
    [ "Start", "class_ball_movement.html#a30553c43b5f0edb4ab0b3d1c4b269993", null ],
    [ "Update", "class_ball_movement.html#adec04489bea52562cc6e1e0048c23bc7", null ]
];