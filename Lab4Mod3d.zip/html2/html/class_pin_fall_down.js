var class_pin_fall_down =
[
    [ "power", "class_pin_fall_down.html#a8658bded276508aad0b6297af75b5d56", null ],
    [ "radius", "class_pin_fall_down.html#aa89b8c30295e795a3355e45fd4def19e", null ]
];