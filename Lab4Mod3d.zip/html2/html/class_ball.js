var class_ball =
[
    [ "setballSpeed", "class_ball.html#a655a2ac68857807d79d7b32c3dc46b19", null ],
    [ "Start", "class_ball.html#ac82387db69cc078a600870dba29a064c", null ],
    [ "Update", "class_ball.html#a237aaf0107c7bf3d7812dc8a9a642593", null ],
    [ "ballSpeed", "class_ball.html#a9f152c3ceba4ace75c2c87d73fc40cea", null ],
    [ "controller", "class_ball.html#ae623e52a072614fd991c767b315c56d7", null ],
    [ "move", "class_ball.html#a4fa4815ebae31c377b851144151c9f3d", null ],
    [ "turnSpeed", "class_ball.html#a7adb29497e06c56dc9dd0d55ded63aa2", null ]
];