var class_color_change =
[
    [ "Start", "class_color_change.html#a7851038dd8fb7ee037e3572e5ea0820e", null ],
    [ "Update", "class_color_change.html#adcff0a9a82823d3e0c08ac2aa6dad8c6", null ],
    [ "nextColor", "class_color_change.html#a24d6e49ea48325fb5fb722bb80264339", null ],
    [ "possibleColors", "class_color_change.html#a82d62c6de3e5c99613d876af2de00627", null ],
    [ "ren", "class_color_change.html#a325e912ee57c39a0fa9187988dac05de", null ]
];