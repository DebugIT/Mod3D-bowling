var class_jumping_pins =
[
    [ "force", "class_jumping_pins.html#af7d195dc1a8351eb4a6f08bd77032e74", null ],
    [ "maxNumberOfCollisions", "class_jumping_pins.html#a31a3fe87e85993182f3ed08538bf85cf", null ],
    [ "radius", "class_jumping_pins.html#ae0c8d6f8c73c3efbdaf4e6fbf9a9299d", null ],
    [ "up", "class_jumping_pins.html#a16bacff923dbd14b883bb6ec3262b78e", null ]
];