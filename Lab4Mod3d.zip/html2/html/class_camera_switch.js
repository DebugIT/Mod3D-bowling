var class_camera_switch =
[
    [ "cameras", "class_camera_switch.html#a4797769d49b74b29a261aa81c820b25d", null ],
    [ "camerasCount", "class_camera_switch.html#a61b4cf53f1fc86e226eefdb6685ab777", null ]
];