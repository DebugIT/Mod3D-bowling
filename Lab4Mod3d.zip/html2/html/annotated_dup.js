var annotated_dup =
[
    [ "AddPrefab", "class_add_prefab.html", "class_add_prefab" ],
    [ "Ball", "class_ball.html", "class_ball" ],
    [ "BallMovement", "class_ball_movement.html", "class_ball_movement" ],
    [ "CameraSwitch", "class_camera_switch.html", "class_camera_switch" ],
    [ "CircularPinMove", "class_circular_pin_move.html", null ],
    [ "ColorChange", "class_color_change.html", "class_color_change" ],
    [ "DeletePin", "class_delete_pin.html", null ],
    [ "Ex2Move", "class_ex2_move.html", null ],
    [ "ExplodeScript", "class_explode_script.html", "class_explode_script" ],
    [ "JumpingPins", "class_jumping_pins.html", "class_jumping_pins" ],
    [ "lookAtScript", "classlook_at_script.html", "classlook_at_script" ],
    [ "ObjectMove", "class_object_move.html", "class_object_move" ],
    [ "PinFallDown", "class_pin_fall_down.html", "class_pin_fall_down" ],
    [ "SquareMove", "class_square_move.html", null ],
    [ "superScript", "classsuper_script.html", "classsuper_script" ],
    [ "test", "classtest.html", "classtest" ],
    [ "TmpMove", "class_tmp_move.html", "class_tmp_move" ]
];